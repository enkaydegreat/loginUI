
import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  const Login({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
       // backgroundColor: Colors.white,
        appBar: AppBar(
          title: Text('Login Screen App'),
          centerTitle: true,
          backgroundColor: Colors.blue,
        ),
        body: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            
            children: <Widget>[
              SizedBox(
                height: 100.0,
              ),
              Text('Codeplayon',
              style: TextStyle(
                fontSize: 40,
                color: Colors.blue[500],
                fontWeight: FontWeight.bold,
              ),),

              SizedBox(
                height: 10.0,
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(30, 0, 30, 0),
                child: TextField(
                  
                  decoration: InputDecoration(
                    hintText: 'Username',
                    border: OutlineInputBorder(
                      borderRadius:   BorderRadius.circular(30)
                    )
                  ),
                ),
              ),

              SizedBox(
                height: 10.0,
              ),


            Padding(
                padding: EdgeInsets.fromLTRB(30, 0, 30, 0),
                child: TextField(
                  obscureText: true,
                  
                  decoration: InputDecoration(
                    hintText: 'Password',
                    border: OutlineInputBorder(
                      borderRadius:   BorderRadius.circular(30)
                    )
                  ),
                ),
              ),


              SizedBox(
                height: 10.0,
              ),

              Text('Forgot Pasword',
              style: TextStyle(
                 color: Colors.blue[500],
                 fontWeight: FontWeight.bold, 
              ),),

              
              RaisedButton(
                onPressed: (){
                //on click sign in
              },
              child: Text('Login',
              style: TextStyle(
                color: Colors.white,
              ),
              ),
              color: Colors.blue[500],)

            ],

          ),
        ),
    
      ),
    );
  }
}
